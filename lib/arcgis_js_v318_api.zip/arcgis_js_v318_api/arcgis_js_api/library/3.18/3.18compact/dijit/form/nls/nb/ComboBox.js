//>>built
define("dijit/form/nls/nb/ComboBox",{previousMessage:"Tidligere valg",nextMessage:"Flere valg"});