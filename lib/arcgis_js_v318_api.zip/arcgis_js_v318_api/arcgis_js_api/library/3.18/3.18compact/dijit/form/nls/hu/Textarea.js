//>>built
define("dijit/form/nls/hu/Textarea",{iframeEditTitle:"szerkeszt\u00e9si ter\u00fclet",iframeFocusTitle:"szerkeszt\u00e9si ter\u00fclet keret"});