//>>built
define("dijit/form/nls/sr/Textarea",{iframeEditTitle:"oblast za ure\u0111ivanje",iframeFocusTitle:"okvir oblasti za ure\u0111ivanje"});