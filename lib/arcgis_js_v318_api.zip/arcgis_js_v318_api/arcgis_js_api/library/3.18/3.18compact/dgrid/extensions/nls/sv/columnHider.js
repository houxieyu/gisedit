//>>built
define("dgrid/extensions/nls/sv/columnHider",{popupLabel:"Visa eller d\u00f6lj kolumner"});