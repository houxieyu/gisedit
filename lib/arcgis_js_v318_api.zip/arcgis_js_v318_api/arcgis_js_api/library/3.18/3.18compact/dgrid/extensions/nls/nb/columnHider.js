//>>built
define("dgrid/extensions/nls/nb/columnHider",{popupLabel:"Vis eller skjul kolonner"});