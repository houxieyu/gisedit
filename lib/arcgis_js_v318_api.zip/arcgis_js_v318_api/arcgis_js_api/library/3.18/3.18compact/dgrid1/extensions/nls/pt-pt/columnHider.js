//>>built
define("dgrid1/extensions/nls/pt-pt/columnHider",{popupLabel:"Exibir ou esconder colunas"});