//>>built
define("dgrid1/extensions/nls/pl/columnHider",{popupLabel:"Wy\u015bwietl lub ukryj kolumny"});